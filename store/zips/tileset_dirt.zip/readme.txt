License: CC0
Author: TinyWorlds

created for fun
if you're looking for game tutorials and generators, check out www.tinyworlds.org/resources
