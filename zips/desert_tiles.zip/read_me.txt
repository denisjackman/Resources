Hi, I hope you like these assets. You can get more like this from my site www.gamedeveloperstudio.com
If you like them or use them why not consider supporting my site, the more support the more assets I can produce.

If you like these tiles there's a full set on the site http://www.gamedeveloperstudio.com/graphics/viewgraphic.php?item=1h41133a035v583551


Thanks 

Robert Brooks